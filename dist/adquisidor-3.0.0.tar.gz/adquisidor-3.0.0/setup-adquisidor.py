from setuptools import setup
import adquisidor

setup(
    name='adquisidor',
    version=adquisidor.__version__,
    description='Modulo de defincion de la adquisicion',
    author='VV',
    author_email='vvalotto@gmail.com',
    packages=['adquisidor'],
)
