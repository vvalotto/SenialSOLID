from setuptools import setup
import utilidades

setup(
    name='persistidor',
    version=utilidades.__version__,
    description='Modulo de aspectos transversales utilitarios',
    author='VV',
    author_email='vvalotto@gmail.com',
    packages=['utilidades'],
)