from setuptools import setup

setup(
    name='adquisidor',
    version='1.0.0',
    description='Modulo de defincion de la adquisicion',
    author='VV',
    author_email='vvalotto@gmail.com',
    packages=['adquisidor'],
)
