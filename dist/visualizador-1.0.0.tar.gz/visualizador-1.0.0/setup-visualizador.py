from setuptools import setup

setup(
    name='visualizador',
    version='1.0.0',
    description='Modulo de defincion del interfaz de consola',
    author='VV',
    author_email='vvalotto@gmail.com',
    packages=['visualizador'],
)
