from setuptools import setup
import visualizador


setup(
    name='visualizador',
    version=visualizador.__version__,
    description='Modulo de defincion del interfaz de consola',
    author='VV',
    author_email='vvalotto@gmail.com',
    packages=['visualizador'],
)
