from setuptools import setup

setup(
    name='modelo',
    version='1.0.0',
    description='Definicion de las entidades',
    author='VV',
    author_email='vvalotto@gmail.com',
    packages=['modelo'],
)
